# RIDE OR DIE — Official Brand Assets

This folder is the single source of truth for RIDE OR DIE branding.

## Approved logo direction

- Integrated R/D emblem
- Broken circular design
- Central blade/light motif
- Ivory and crimson duality
- Rose motif
- Elegant gothic typography
- Tagline: **LOVE. | SURVIVE. | REMEMBER.**

Preserve the approved logo artwork and proportions. Do not redraw, stretch,
recolour, add effects to, or substitute the official mark without approval.

## Asset filenames

Upload the approved logo artwork using these filenames:

| Filename | Purpose |
|---|---|
| `logo-primary.png` | Main full-colour logo |
| `logo-primary-transparent.png` | Main logo with transparent background |
| `logo-emblem.png` | Standalone R/D emblem |
| `logo-monochrome.png` | Single-colour logo for adaptable use |

Use PNG for raster assets. If vector originals are available, also include
`logo-primary.svg` and `logo-emblem.svg`.

## Usage

- Use the primary logo for the game's title screen, website and promotional
  materials.
- Use the standalone emblem for app icons, small UI placements and favicons.
- Use the monochrome version where the full-colour mark is unsuitable.
- Keep clear space around the logo and maintain legibility at small sizes.
- Do not use an unapproved AI recreation as a replacement for the master logo.

## Important

The actual approved logo image is not included in this starter folder because
the image file was not attached to this request. Add the original approved
artwork using the filenames above before treating this folder as complete.
